import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/AnnonZerp/VolvoxTV/master/home.txt'
addon = xbmcaddon.Addon('plugin.video.VolvoxTV')