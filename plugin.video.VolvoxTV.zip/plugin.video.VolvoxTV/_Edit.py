import xbmcaddon

MainBase = 'http://goo.gl/oNkF0a'
addon = xbmcaddon.Addon('plugin.video.VolvoxTV')